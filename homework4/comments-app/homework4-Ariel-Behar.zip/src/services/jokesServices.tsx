const baseUrl:string  = 'https://geek-jokes.sameerkumar.website/api';

export const getJoke = () => fetch(baseUrl);

import styled from 'styled-components'

export const StyledCommentFormDiv = styled.div`

    form {
        display: flex;
        flex-direction: column;

        input[type="submit"] {
            margin-top: 10px;
        }
    }
    

`